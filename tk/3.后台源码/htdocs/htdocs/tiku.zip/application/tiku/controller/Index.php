<?php
namespace app\tiku\controller;

use think\Controller;
use app\tiku\Controller\Common;

class Index extends Common
{
	public function index()//首页
	{
		$table=db('member');
		$userinfo=$table->where('id='.session('userid'))->find();
		$this->assign('userinfo',$userinfo);
		return $this->fetch();
	}
	public function quit()//退出
	{
		session_destroy();
		$this->success('退出成功','Login/index');
	}
	public function memberlist()//会员列表
	{
		$db=db('member');
		$uselist=$db->paginate(config('paginate.list_rows'));
		$this->assign('page',$uselist->render());
		$this->assign('uselist',$uselist);
		return $this->fetch();
	}
	public function addmember()//会员添加
	{
		$db=db('auth_group');
		$grouplist=$db->select();
		$this->assign('grouplist',$grouplist);		
		return $this->fetch();
	}
	public function do_addmember()
	{	
		$db=db('member');
		$data=input('post.');
		$data['password']=md5($data['password']);
		$file=request()->file('photo');
		$files=$file->move(PUBLIC_PATH.'Uploads/');
		$data['photo']=$files->getSavename();
		//$data['password']=md5(config('default_password'));//默认密码值
		$info=$db->insert($data);
		if($info)
		{
			$gdata['uid']=$db->getLastInsID();
			$table=db('auth_group_access');
			$tbinfo=$table->insert($gdata);
			if($tbinfo)
			{
				$this->success('会员添加成功','Index/memberlist');
			}
		}
	}
	public function delmember()//会员列表删除
	{
		$id=input('id');
		$stu=db('member');
		$info=$stu->where('id in('.$id.')')->delete();
		if($info)
		{
			$this->success('删除成功','Index/memberlist');
		}
		else{
			$this->error('删除失败');
		}
	}
	public function upmember()//会员修改
	{
		$id=input('id');
		$table=db('member');
		$info=$table->where('id='.$id)->find();
		$this->assign('info',$info);
		return $this->fetch();
	}
	public function do_upmember()
	{
		$data=input('post.');
		$id=input('uid');
		$data['id']=$data['uid'];
		unset($data['uid']);
		$file=request()->file('photo');
		if($file)
		{
			$fileinfo=$file->move(config('upload_path'));
			$data['photo']=$fileinfo->getSavename();
		}
		$table=db('member');
		$info=$table->update($data);
		if($info)
		{
			$this->success('修改成功','Index/memberlist');
		}
		else{
			$this->error('修改失败');
		}
	}
	public function addsubject()//科目添加
	{
		$db=db('auth_group');
		$grouplist=$db->select();
		$this->assign('grouplist',$grouplist);		
		return $this->fetch();
	}
	public function do_addsubject()
	{
		$db=db('subject');
		$data=input('post.');
		$info=$db->insert($data);
		if($info)
		{
			$gdata['uid']=$db->getLastInsID();
			$table=db('auth_group_access');
			$tbinfo=$table->insert($gdata);
			if($tbinfo)
			{
				$this->success('科目添加成功','Index/subjectlist');
			}
		}
	}
	public function subjectlist()//科目列表
	{
		$db=db('subject');
		$subjectlist=$db->paginate(config('paginate.list_rows'));
		$this->assign('page',$subjectlist->render());
		$this->assign('subjectlist',$subjectlist);
		return $this->fetch();
	}
	public function upsubject()//科目修改
	{
		$id=input('id');
		$table=db('subject');
		$info=$table->where('id in('.$id.')')->find();
		$this->assign('info',$info);
		return $this->fetch();
	}
	public function do_upsubject()
	{
		$data=input('post.');
		$id=input('uid');
		$data['id']=$data['uid'];
		unset($data['uid']);
		$table=db('subject');
		$info=$table->update($data);
		if($info)
		{
			$this->success('修改成功','Index/subjectlist');
		}
		else{
			$this->error('修改失败');
		}
	}
	public function delsubject()//科目删除
	{
		$id=input('id');
		$db=db('subject');
		$info=$db->where('id in('.$id.')')->delete();
		if($info)
		{
			$this->success('科目删除成功','Index/subjectlist');
		}
		else{
			$this->error('科目删除失败');
		}
	}
	public function addanswer()//答案添加
	{
		$db=db('auth_group');
		$grouplist=$db->select();
		$this->assign('grouplist',$grouplist);		
		return $this->fetch();
	}
	public function do_addanswer()
	{	
		$data=db('answer');
		$table=input('post.');
		$info=$data->insert($table);
		if($info)
		{
			$this->success('添加成功','Index/answerlist');
		}
		else{
			$this->error('添加失败');
		}
	}
	public function delanswer()//答案删除
	{
		$id=input('id');
		$db=db('answer');
		$info=$db->where('id in('.$id.')')->delete();
		if($info)
		{
			$this->success('删除成功','Index/answerlist');
		}
		else{
			$this->error('删除失败');
		}
	}
	public function upanswer()//答案修改
	{
		$id=input('id');
		$data=db('answer');
		$info=$data->where('id in('.$id.')')->find();
		$this->assign('info',$info);
		return $this->fetch();
	}
	public function do_upanswer()
	{
		$data=input('post.');
		$id=input('id');	
		$table=db('answer');
		$info=$table->update($data);
		if($info!==false)
		{
			$this->success('修改成功','Index/answerlist');
		}else{
			$this->error('修改失败');
		}
		return $this->fetch();
	}
	public function answerlist()//答案列表
	{
		$db=db('answer');
		$answerlist=$db->paginate(config('paginate.list_rows'));
		$this->assign('page',$answerlist->render());
		$this->assign('answerlist',$answerlist);
		return $this->fetch();
	}
	public function ceshi()
	{
		$db=db('answer');
		$list=$db->alias('a')->join('timu','timu.id=a.id')->select();
	}
	public function addtimu()  //题目添加
	{
		$db=db('subject');
		$grouplist=$db->select();
		$this->assign('grouplist',$grouplist);
		return $this->fetch();
	}
	public function do_addtimu()  //处理题目添加
	{
		$data=input('post.');
		$file=request()->file('photo'); //接受图片的名字
		$fileinfo=$file->move(config('upload_path')); //创建放图片的文件夹 得到存的信息
		$data['photo']=$fileinfo->getSavename();//求图像返回路径和名称
		$table=db('problem');
		$info=$table->insert($data);
		if($info)
		{
			return $this->success('添加成功','Index/timulist');
		}
		else{
			return $this->error('添加失败');
		}
	}
	public function timulist()//题目列表
	{
		$db=db('problem');
		$uselist=$db->paginate(config('paginate.list_rows'));
		$this->assign('page',$uselist->render());
		$this->assign('uselist',$uselist);
		return $this->fetch();
	}
	public function deproblem()  //删除题目的方法
	{
		$stu=db('problem');
		$id=input('id');
		$info=$stu->where('id in ('.$id.')')->delete();
		if($info)
		{
			$this->success('删除成功','Index/timulist');
		}else{
			$this->error('删除失败');
		}
	}
	public function uptimu()  // 修改题目
	{
		$id=input('id');//显示内容
		$info=db('problem')->where('id='.$id)->find();
		//echo "<pre>";
		//print_r($info);
		$this->assign('info',$info);
		$db=db('subject');  //显示科目
		$grouplist=$db->select();
		//print_r($grouplist);
		$this->assign('grouplist',$grouplist);
		return $this->fetch();
	}
	public function do_timu()   //处理题目修改
	{
		$data=input('post.');
		$id=$data['uid'];
		unset($data['uid']);
		$file=request()->file('photo');
		if($_FILES['photo']['error']==0)
		{
			$fileinfo=$file->move(config('upload_path'));
			$data['photo']=$fileinfo->getSavename();
		}
		$info=db('problem')->where('id='.$id)->update($data);
		if($info)
		{
			return $this->success('修改成功','Index/timulist');
		}else{
			return "修改失败";
		}
	}
	//检查规则科目名称是否存在
	public function checkenname()
	{
		$name=input('post.names');
		$db=db('subject');
		$info=$db->where("subname='".$name."'")->find();
		if($info)
		{
			$adata=[
				'status'=>1,
				'msg'=>'此科目名称已存在'
			];
		}
		else{
			$adata=[
				'status'=>0,
				'msg'=>'此科目名称可用'
			];
		}
		return json($adata);
	}
	//检查规则科目描述是否存在
	public function checkzhname()
	{
		$name=input('post.names');
		$db=db('subject');
		$info=$db->where("intro='".$name."'")->find();
		if($info)
		{
			$adata=[
				'status'=>1,
				'msg'=>'此科目描述已存在'
			];
		}
		else{
			$adata=[
				'status'=>0,
				'msg'=>'此科目描述可用'
			];
		}
		return json($adata);
	}
	
}
?>